//
//  ViewController.swift
//  Frankenstein
//
//  Created by Isaac rodrigo sopedra on 31/07/2020.
//  Copyright © 2020 Isaac rodrigo sopedra. All rights reserved.
//

import UIKit
import ARKit

extension float4x4 {
    var translation: SIMD3<Float> {
        let translation = self.columns.3
        return SIMD3<Float>(translation.x, translation.y, translation.z)
    }
}
class ViewController: UIViewController {
    
    @IBOutlet var sceneView: ARSCNView!
    override func viewDidLoad() {
        super.viewDidLoad()
        myBox() //creo una caja en la escena
        addGestureToScene() //añado reconocimiento de gestos
        
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARWorldTrackingConfiguration()
        sceneView.session.run(configuration)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    func myBox(x: Float = 0, y: Float = 0, z: Float = -0.2) {
       let box = SCNBox(width: 0.1, height: 0.1, length: 0.1, chamferRadius: 0)
       
       let boxNode = SCNNode()
       boxNode.geometry = box
       boxNode.position = SCNVector3(x, y, z)
       
       sceneView.scene.rootNode.addChildNode(boxNode)
    }
    
    func addGestureToScene() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.didTap(withGestureRecognizer:)))
        sceneView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    @objc func didTap(withGestureRecognizer recognizer: UIGestureRecognizer) {
        let tapLocation = recognizer.location(in: sceneView)
        let hitTestResults = sceneView.hitTest(tapLocation)
        guard let node = hitTestResults.first?.node else {
            let hitTestResultsWithFeaturePoints = sceneView.hitTest(tapLocation, types: .featurePoint)
            if let hitTestResultWithFeaturePoints = hitTestResultsWithFeaturePoints.first {
                let translation = hitTestResultWithFeaturePoints.worldTransform.translation
                myBox(x: translation.x, y: translation.y, z: translation.z)
                
                
            }
            return
        }
        node.removeFromParentNode()
    }
    
    
}

